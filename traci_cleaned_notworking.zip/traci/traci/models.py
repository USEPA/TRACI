# models.py (app)
# !/usr/bin/env python3
# coding=utf-8
# young.daniel@epa.gov


"""
Definition of models.
"""

from django.db import models

# Create your models here.
